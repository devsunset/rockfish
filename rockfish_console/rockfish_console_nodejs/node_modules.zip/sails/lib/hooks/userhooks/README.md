## Userhooks Hook

This hook loads hooks from the user hooks directory, configurable in `sails.config.paths.hooks` (defaults to `api/hooks`) of a sails app.  If the directory doesn't exist, this hook is a no-op.

##### Contributing to this hook
Not a good place to jump in right now.  Please tweet @mikermcneil before working on this part!
