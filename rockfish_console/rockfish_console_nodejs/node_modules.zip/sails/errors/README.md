# Errors


> TODO:
> 1. move messages into `sails-stringfile`
> 2. Ideally we don't call `process.exit()` at all- instead, consistently call sails.lower().  See comment at bottom of `fatal.js`.
> 3. This directory can probably be deleted.